<?php
include_once("functions.php");
VerificarVencimento();
?>