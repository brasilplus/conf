ALTER TABLE  `opcoes` ADD  `OpcoesEmailTeste` VARCHAR( 11 ) NOT NULL DEFAULT  'N' AFTER  `OpcoesEmailTemporario`;
ALTER TABLE  `opcoes` ADD  `OpcoesCupom` VARCHAR( 11 ) NOT NULL DEFAULT  'N' AFTER  `OpcoesEmailTeste`;
UPDATE `opcoes` SET  `OpcoesEmailTeste` =  'S' WHERE `id` =1;
UPDATE `opcoes` SET  `OpcoesCupom` =  'S' WHERE  `id` =1;