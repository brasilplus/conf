CREATE TABLE IF NOT EXISTS `captcha` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(11) NOT NULL DEFAULT 'S',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

INSERT INTO `captcha` (`id`, `status`) VALUES
(1, 'S');

ALTER TABLE  `planos` ADD  `nomeplano` VARCHAR( 250 ) NULL DEFAULT NULL AFTER  `CadUser`;

UPDATE `versao` SET `versao` = '2.7';

CREATE TABLE IF NOT EXISTS `email_teste` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(250) DEFAULT NULL,
  `CadUser` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;


CREATE TABLE IF NOT EXISTS `cupom` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CadUser` varchar(250) DEFAULT NULL,
  `CriadoEm` varchar(250) DEFAULT NULL,
  `Cupom` varchar(250) DEFAULT NULL,
  `UserDescontar` varchar(250) DEFAULT NULL,
  `UserDescontarEm` varchar(250) DEFAULT NULL,
  `dias` varchar(250) DEFAULT NULL,
  `perfil` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `rede_social` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CadUser` varchar(250) DEFAULT NULL,
  `facebook` mediumtext,
  `whatsapp` mediumtext,
  `telegram` mediumtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `arquivo_backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(250) DEFAULT NULL,
  `local` mediumtext,
  `data` varchar(250) DEFAULT NULL,
  `size` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `backup_automatizado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(11) NOT NULL DEFAULT 'N',
  `tempo` varchar(250) NOT NULL,
  `horario` varchar(250) NOT NULL,
  `server` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `server` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(250) DEFAULT NULL,
  `ip` mediumtext,
  `porta` mediumtext NOT NULL,
  `user` mediumtext NOT NULL,
  `senha` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `bit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CadUser` varchar(250) DEFAULT NULL,
  `usuario` varchar(250) DEFAULT NULL,
  `api` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;