ALTER TABLE  `rev` ADD  `LimiteUser` VARCHAR( 250 ) NULL DEFAULT NULL AFTER  `LimiteTeste`;
ALTER TABLE  `admin` ADD  `data_premio` VARCHAR( 250 ) NULL DEFAULT NULL AFTER  `obs`;
ALTER TABLE  `admin` ADD  `conexao` INT( 11 ) NULL DEFAULT NULL AFTER  `data_premio`;
ALTER TABLE  `rev` ADD  `conexao` INT( 11 ) NULL DEFAULT NULL AFTER  `LimiteUser`;
ALTER TABLE  `admin` ADD  `grupo` INT( 11 ) NOT NULL DEFAULT  '1' AFTER  `conexao`;
ALTER TABLE  `rev` ADD  `grupo` INT( 11 ) NOT NULL DEFAULT  '2' AFTER  `conexao`;
ALTER TABLE  `usuario` ADD  `grupo` INT( 11 ) NOT NULL DEFAULT  '3' AFTER  `obs`;
ALTER TABLE  `teste` ADD  `grupo` INT( 11 ) NOT NULL DEFAULT  '4' AFTER  `obs`;
ALTER TABLE  `admin` ADD  `PrePago` VARCHAR( 11 ) NOT NULL DEFAULT  'N' AFTER  `grupo`;