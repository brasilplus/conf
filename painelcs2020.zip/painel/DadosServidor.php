<?php
// ======================================
//         ~ Informa��es MySQL ~
// ======================================
// Servidor MySQL
$_MDouglas['servidor'] = 'localhost';
// Usu�rio MySQL
$_MDouglas['usuario'] = 'root';
// Senha MySQL
$_MDouglas['senha'] = 'mumuca20';

// ======================================
//          ~ Bancos de Dados ~
// ======================================
$_MDouglas['painel_acessos'] = 'PAINELCS_ACESSO';
$_MDouglas['painel_geral'] = 'PAINELCS_GERAL';
$_MDouglas['painel_user'] = 'PAINELCS_USER';